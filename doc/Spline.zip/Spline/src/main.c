/*
 ============================================================================
 Name        : Spline.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "cmath.h"

int main(void) {

	double x[] = { 1.0, 2.0, 3.0, 4.0, 5.0 };
	double y[] = { 0.8, 0.4, 0.38, -2.0, -1.3};

	double b[5], c[5], d[5];
	int iflag = 0, last = 0, i = 0;

	double fy = 0.0;

	spline (5, 1, 1, 0.0, 0.0, x, y, b, c, d, &iflag);


	for(;i<50;i++){
		fy = seval (5, 0.1*i, x, y, b, c, d, &last);
		printf("%f\n", fy);
	}

	return EXIT_SUCCESS;
}
